<?php
$a="Topi";
$b="Bundar";
echo $a." Saya ".$b.", ".$b." ".$a." Saya.";

?>
