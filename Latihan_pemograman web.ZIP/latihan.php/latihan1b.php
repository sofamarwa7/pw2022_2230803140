<?php
$a1=10;
echo "Aku adalah angka ".$a1.".<br>";
echo "jika aku di kali 8, jumlahku sekarang ".($a1=($a1*8)).".<br>";
echo "jika aku di bagi 4, jumlahku sekarang ".($a1=($a1/4)).".<br>";
echo "jika aku di kurang 6, jumlahku sekarang ".($a1=($a1-6)).".<br>";
echo "jika aku di tambah 2, jumlahku sekarang ".($a1=($a1+2)).".<br>";

?>